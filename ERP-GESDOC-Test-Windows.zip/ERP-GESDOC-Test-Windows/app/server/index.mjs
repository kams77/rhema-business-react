// server/index.mjs — démarrage du serveur ERP-GESDOC.
//
// Variables d'environnement :
//   PORT            Port HTTP (défaut 8080)
//   DB_DRIVER       "mysql" (défaut) ou "memory" (essais sans base, données perdues à l'arrêt)
//   DB_HOST, DB_PORT, DB_USER, DB_PASSWORD, DB_NAME   Connexion MariaDB / MySQL
//   SETUP_CODE      Code demandé lors de la première initialisation (fortement recommandé)
//   TRUST_PROXY     "true" si un reverse proxy (Synology, Nginx…) est placé devant (défaut true)
//   TRUSTED_PROXIES Adresses d'où les en-têtes X-Forwarded-* sont acceptés
//                   (défaut « loopback,172.16.0.0/12 » : le NAS et le réseau interne de Docker)
//   COOKIE_SECURE   "true" pour forcer les cookies « Secure » (HTTPS)
//   DIST_DIR        Dossier de l'application compilée (défaut ../dist)
import http from 'node:http';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createApp } from './app.mjs';
import { SESSION_MAX_MS } from './auth.mjs';

const here = path.dirname(fileURLToPath(import.meta.url));
const env = process.env;

// « npm run server:memoire » : essai sans base de données (fonctionne aussi sous Windows).
if (process.argv.includes('--memoire')) {
  env.DB_DRIVER = 'memory';
  env.SETUP_CODE ??= 'essai';
}

const config = {
  port: Number(env.PORT || 8080),
  distDir: path.resolve(env.DIST_DIR || path.join(here, '..', 'dist')),
  setupCode: env.SETUP_CODE || '',
  trustProxy: (env.TRUST_PROXY ?? 'true') !== 'false',
  trustedProxies: env.TRUSTED_PROXIES || 'loopback,172.16.0.0/12',
  cookieSecure: env.COOKIE_SECURE === 'true',
  dev: env.NODE_ENV === 'development',
};

async function createDb() {
  if ((env.DB_DRIVER || 'mysql') === 'memory') {
    const { createMemoryDb } = await import('./db-memory.mjs');
    console.warn('[db] Stockage EN MÉMOIRE : les données seront perdues à l\'arrêt du serveur.');
    return createMemoryDb();
  }
  const { createMysqlDb } = await import('./db-mysql.mjs');
  return createMysqlDb({
    host: env.DB_HOST || 'localhost',
    port: Number(env.DB_PORT || 3306),
    user: env.DB_USER || 'erp_workflow',
    password: env.DB_PASSWORD || '',
    database: env.DB_NAME || 'erp_workflow',
  });
}

// Refuse de démarrer avec les valeurs d'exemple du fichier docker-compose.yml.
const placeholders = ['DB_PASSWORD', 'SETUP_CODE'].filter(k => String(env[k] || '').includes('CHANGEZ_MOI'));
if (placeholders.length) {
  console.error(`[erp-gesdoc] Modifiez d'abord ${placeholders.join(' et ')} dans docker-compose.yml (valeurs « CHANGEZ_MOI »).`);
  process.exit(1);
}

const db = await createDb();
await db.migrate();
if ((await db.countUsers()) === 0 && config.setupCode.length < 8 && db.kind !== 'memory') {
  // Sans code solide, la première personne qui atteint le serveur deviendrait Direction Générale.
  console.error('[setup] Base vide : définissez un SETUP_CODE d\'au moins 8 caractères avant le premier démarrage.');
  process.exit(1);
}

const server = http.createServer(createApp({ db, config }));
server.requestTimeout = 120_000;
server.listen(config.port, () => {
  console.log(`[erp-gesdoc] Serveur prêt sur le port ${config.port} (stockage : ${db.kind}, application : ${config.distDir})`);
});

// Nettoyage des sessions expirées toutes les heures.
setInterval(() => db.purgeSessions(Date.now() - SESSION_MAX_MS).catch(() => {}), 60 * 60 * 1000).unref();

const shutdown = async signal => {
  console.log(`[erp-gesdoc] Arrêt (${signal})…`);
  server.close();
  await db.close().catch(() => {});
  process.exit(0);
};
process.on('SIGTERM', shutdown);
process.on('SIGINT', shutdown);
